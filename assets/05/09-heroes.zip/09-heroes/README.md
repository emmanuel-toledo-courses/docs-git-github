# Objetivos de la repositorio

Este proyecto se encarga de manejar los planes de la liga de la justicia


## Notas
Pueden hacer lo que quieran...
